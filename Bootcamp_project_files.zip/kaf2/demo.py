from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import row_number, col, count
import sys
import json

def task_1():
    spark = SparkSession.builder \
        .appName("task1") \
        .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
        .getOrCreate()

    # s3_path = sys.argv[1]
    # jdbc_url = sys.argv[sys.argv.index('--jdbc_url') + 1]
    # connection_properties = sys.argv[sys.argv.index('--cp')+1]
    # table_name = sys.argv[sys.argv.index('--table_name')+1]
    #
    # # Parse the JSON string back into a Python dictionary
    # connection_properties = json.loads(connection_properties)
    s3_path = '/home/madhav/Documents/Bootcamp_Project/bootcamp-project/data/employee_data.csv'

    jdbc_url = "jdbc:postgresql://34.229.143.113/advance"
    connection_properties = {
        "user": "priyanshu",
        "password": "1234",
        "driver": "org.postgresql.Driver",
        "batchsize": "50000"  # Set the batch size to 50000 records
    }
    table_name = 'employee_data_stg'


    spark_df = spark.read.csv(s3_path, header=True, inferSchema=True)

    window_spec = Window.partitionBy("emp_id").orderBy("emp_id")
    spark_df = spark_df.withColumn("row_num", row_number().over(window_spec)) \
        .filter(col("row_num") == 1) \
        .drop("row_num")

    # Write Spark DataFrame to PostgreSQL table
    spark_df.write\
        .option("truncate", "true") \
        .jdbc(url=jdbc_url,
              table=table_name,
              mode="overwrite",  # or "overwrite" depending on your requirement
              properties=connection_properties)

    spark.stop()

task_1()