staging_to_final= '''
Truncate table SCD_employee_strikes_table;

Insert into SCD_employee_strikes_table select * from staging_SCD_employee_strikes_table;

Truncate table staging_SCD_employee_strikes_table;

UPDATE employee_strike_table_dim AS est
SET strike_count = sed.strike_count
FROM SCD_employee_strikes_table AS sed
WHERE est.emp_id = sed.employee_id;

UPDATE SCD_employee_strikes_table s
SET current_salary = e.salary
FROM employee_ts_table_dim e
WHERE s.employee_id = e.emp_id;

'''
