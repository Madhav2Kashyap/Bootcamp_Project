from pyspark.sql import SparkSession
from pyspark.sql.functions import col, array, udf
from pyspark.sql.types import ArrayType, DateType, StringType
import sys
import json

def SC_columns_adjustment():
    spark = SparkSession.builder \
        .appName("updation_task") \
        .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
        .getOrCreate()

    jdbc_url = sys.argv[sys.argv.index('--jdbc_url') + 1]
    connection_properties = sys.argv[sys.argv.index('--cp') + 1]

    connection_properties = json.loads(connection_properties)
    # Define the SQL query with explicit casting to DateType
    query = """
        SELECT 
            employee_id, 
            original_salary, 
            current_salary, 
            strike_count,
            CAST(sc_1 AS DATE) AS sc_1,
            CAST(sc_2 AS DATE) AS sc_2,
            CAST(sc_3 AS DATE) AS sc_3,
            CAST(sc_4 AS DATE) AS sc_4,
            CAST(sc_5 AS DATE) AS sc_5,
            CAST(sc_6 AS DATE) AS sc_6,
            CAST(sc_7 AS DATE) AS sc_7,
            CAST(sc_8 AS DATE) AS sc_8,
            CAST(sc_9 AS DATE) AS sc_9
        FROM 
            SCD_employee_strikes_table
    """

    df = spark.read.jdbc(url=jdbc_url, table=f"({query}) AS temp", properties=connection_properties)

    def shift_dates(*cols):
        non_nulls = [x for x in cols if x is not None]
        nulls = [None] * (len(cols) - len(non_nulls))
        return non_nulls + nulls

    # Register UDF
    shift_dates_udf = udf(shift_dates, ArrayType(DateType()))

    # Apply the UDF
    shifted_df = df.withColumn(
        "shifted_dates",
        shift_dates_udf(
            col("sc_1"), col("sc_2"), col("sc_3"), col("sc_4"),
            col("sc_5"), col("sc_6"), col("sc_7"), col("sc_8"), col("sc_9")
        )
    )

    # Split the array back into separate columns
    shifted_df = shifted_df.select(
        col("employee_id"),
        col("original_salary"),
        col("current_salary"),
        col("strike_count"),
        col("shifted_dates")[0].alias("sc_1").cast(DateType()),
        col("shifted_dates")[1].alias("sc_2").cast(DateType()),
        col("shifted_dates")[2].alias("sc_3").cast(DateType()),
        col("shifted_dates")[3].alias("sc_4").cast(DateType()),
        col("shifted_dates")[4].alias("sc_5").cast(DateType()),
        col("shifted_dates")[5].alias("sc_6").cast(DateType()),
        col("shifted_dates")[6].alias("sc_7").cast(DateType()),
        col("shifted_dates")[7].alias("sc_8").cast(DateType()),
        col("shifted_dates")[8].alias("sc_9").cast(DateType())
    )

    # Show the result
    shifted_df.show()
    shifted_df.write \
        .mode("append") \
        .jdbc(url=jdbc_url, table='staging_SCD_employee_strikes_table', properties=connection_properties)


SC_columns_adjustment()
