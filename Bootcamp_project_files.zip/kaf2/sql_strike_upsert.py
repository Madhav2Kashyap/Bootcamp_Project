
strike_upsert = '''
-- First, the update statement
UPDATE employee_strike_table_dim h
SET strike_count = h.strike_count + i.strk_count,
    curr_salary = i.salary
FROM staging_strike_table i 
WHERE h.emp_id = i.employee_id;

-- Next, the insert statement
INSERT INTO employee_strike_table_dim (emp_id, strike_count, last_strike_date, curr_salary)
SELECT i.employee_id, i.strk_count, i.lst_strike_date, i.salary
FROM staging_strike_table i
WHERE i.employee_id NOT IN (
    SELECT emp_id
    FROM employee_strike_table_dim
);
 

'''
