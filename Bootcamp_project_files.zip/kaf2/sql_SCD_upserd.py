SCD_upserd = '''
-- Update existing records in SCD_employee_strikes_table
UPDATE SCD_employee_strikes_table AS scd
SET
    strike_count = dim.strike_count,
    original_salary = dim.curr_salary / POWER(0.9, scd.strike_count),
    current_salary = 0,
    sc_1 = CASE 
               WHEN dim.strike_count >= 1 THEN COALESCE(scd.sc_1, dim.last_strike_date) 
               ELSE scd.sc_1 
           END,
    sc_2 = CASE 
               WHEN dim.strike_count >= 2 THEN COALESCE(scd.sc_2, dim.last_strike_date) 
               ELSE scd.sc_2 
           END,
    sc_3 = CASE 
               WHEN dim.strike_count >= 3 THEN COALESCE(scd.sc_3, dim.last_strike_date) 
               ELSE scd.sc_3 
           END,
    sc_4 = CASE 
               WHEN dim.strike_count >= 4 THEN COALESCE(scd.sc_4, dim.last_strike_date) 
               ELSE scd.sc_4 
           END,
    sc_5 = CASE 
               WHEN dim.strike_count >= 5 THEN COALESCE(scd.sc_5, dim.last_strike_date) 
               ELSE scd.sc_5 
           END,
    sc_6 = CASE 
               WHEN dim.strike_count >= 6 THEN COALESCE(scd.sc_6, dim.last_strike_date) 
               ELSE scd.sc_6 
           END,
    sc_7 = CASE 
               WHEN dim.strike_count >= 7 THEN COALESCE(scd.sc_7, dim.last_strike_date) 
               ELSE scd.sc_7 
           END,
    sc_8 = CASE 
               WHEN dim.strike_count >= 8 THEN COALESCE(scd.sc_8, dim.last_strike_date) 
               ELSE scd.sc_8 
           END,
    sc_9 = CASE 
               WHEN dim.strike_count >= 9 THEN COALESCE(scd.sc_9, dim.last_strike_date) 
               ELSE scd.sc_9 
           END
FROM employee_strike_table_dim AS dim
WHERE scd.employee_id = dim.emp_id;


INSERT INTO SCD_employee_strikes_table (
    employee_id, strike_count, original_salary, sc_1, sc_2, sc_3, sc_4, sc_5, sc_6, sc_7, sc_8, sc_9
)
SELECT 
    dim.emp_id,
    dim.strike_count,
    dim.curr_salary,
    CASE WHEN dim.strike_count >= 1 THEN dim.last_strike_date ELSE NULL END AS sc_1,
    CASE WHEN dim.strike_count >= 2 THEN dim.last_strike_date ELSE NULL END AS sc_2,
    CASE WHEN dim.strike_count >= 3 THEN dim.last_strike_date ELSE NULL END AS sc_3,
    CASE WHEN dim.strike_count >= 4 THEN dim.last_strike_date ELSE NULL END AS sc_4,
    CASE WHEN dim.strike_count >= 5 THEN dim.last_strike_date ELSE NULL END AS sc_5,
    CASE WHEN dim.strike_count >= 6 THEN dim.last_strike_date ELSE NULL END AS sc_6,
    CASE WHEN dim.strike_count >= 7 THEN dim.last_strike_date ELSE NULL END AS sc_7,
    CASE WHEN dim.strike_count >= 8 THEN dim.last_strike_date ELSE NULL END AS sc_8,
    CASE WHEN dim.strike_count >= 9 THEN dim.last_strike_date ELSE NULL END AS sc_9
FROM employee_strike_table_dim AS dim
WHERE NOT EXISTS (
    SELECT 1 FROM SCD_employee_strikes_table AS scd
    WHERE scd.employee_id = dim.emp_id
);

UPDATE SCD_employee_strikes_table
SET
    current_salary = ROUND(original_salary * POWER(0.9, strike_count), 2);

'''