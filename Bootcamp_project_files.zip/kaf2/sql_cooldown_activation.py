
cooldown_activation = '''
UPDATE SCD_employee_strikes_table
SET 
    sc_1 = CASE WHEN strike_count >= 1 AND CURRENT_DATE - sc_1 >= 30 THEN NULL ELSE sc_1 END,
    sc_2 = CASE WHEN strike_count >= 2 AND CURRENT_DATE - sc_2 >= 30 THEN NULL ELSE sc_2 END,
    sc_3 = CASE WHEN strike_count >= 3 AND CURRENT_DATE - sc_3 >= 30 THEN NULL ELSE sc_3 END,
    sc_4 = CASE WHEN strike_count >= 4 AND CURRENT_DATE - sc_4 >= 30 THEN NULL ELSE sc_4 END,
    sc_5 = CASE WHEN strike_count >= 5 AND CURRENT_DATE - sc_5 >= 30 THEN NULL ELSE sc_5 END,
    sc_6 = CASE WHEN strike_count >= 6 AND CURRENT_DATE - sc_6 >= 30 THEN NULL ELSE sc_6 END,
    sc_7 = CASE WHEN strike_count >= 7 AND CURRENT_DATE - sc_7 >= 30 THEN NULL ELSE sc_7 END,
    sc_8 = CASE WHEN strike_count >= 8 AND CURRENT_DATE - sc_8 >= 30 THEN NULL ELSE sc_8 END,
    sc_9 = CASE WHEN strike_count >= 9 AND CURRENT_DATE - sc_9 >= 30 THEN NULL ELSE sc_9 END,
    strike_count = strike_count - (
        CASE
            WHEN CURRENT_DATE - sc_1 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_2 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_3 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_4 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_5 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_6 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_7 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_8 >= 30 THEN 1 ELSE 0 END +
        CASE
            WHEN CURRENT_DATE - sc_9 >= 30 THEN 1 ELSE 0 END
    );
UPDATE SCD_employee_strikes_table    
SET
    current_salary = original_salary * POWER( 0.9, strike_count );

'''
