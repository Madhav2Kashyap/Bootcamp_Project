from pyspark.sql import SparkSession
import sys
import json

def task_3_2():
    spark = SparkSession.builder \
        .appName("task_3_2") \
        .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
        .getOrCreate()

    s3_path = sys.argv[1]
    # jdbc_url = sys.argv[2]
    # connection_properties = sys.argv[3]
    #
    # # Parse the JSON string back into a Python dictionary
    # connection_properties = json.loads(connection_properties)

    jdbc_url = "jdbc:postgresql://35.170.206.20:5432/advance"
    connection_properties = {
        "user": "priyanshu",
        "password": "1234",
        "driver": "org.postgresql.Driver",
        "batchsize": "50000"  # Set the batch size to 50000 records
    }


    spark_df = spark.read.csv(s3_path, header=True, inferSchema=True)

    spark_df = spark_df.dropDuplicates()

    # Write Spark DataFrame to PostgreSQL table
    spark_df.write\
        .option("truncate", "true") \
        .jdbc(url=jdbc_url,
              table='staging_employee_leave_data',
              mode="overwrite",  # or "overwrite" depending on your requirement
              properties=connection_properties)

    spark.stop()

task_3_2()
