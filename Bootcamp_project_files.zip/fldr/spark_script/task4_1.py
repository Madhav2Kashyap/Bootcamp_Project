from pyspark.sql import SparkSession
import sys
import json

def task_4_1_transformation():
    spark = SparkSession.builder\
        .appName("task4_1") \
        .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
        .getOrCreate()

    s3_path = sys.argv[1]
    # jdbc_url = sys.argv[2]
    # connection_properties = sys.argv[3]
    #
    # connection_properties = json.loads(connection_properties)

    jdbc_url = "jdbc:postgresql://35.170.206.20:5432/advance"
    connection_properties = {
        "user": "priyanshu",
        "password": "1234",
        "driver": "org.postgresql.Driver",
        "batchsize": "50000"  # Set the batch size to 50000 records
    }

    spark_df = spark.read.csv(s3_path, header=True, inferSchema=True)

    # Filter the DataFrame for active employees
    spark_df = spark_df.filter(spark_df.status == "ACTIVE")

    # Group by designation and count
    active_counts_df = spark_df.groupBy("designation").count().withColumnRenamed("count", "active_count")

    # Join the count DataFrame with the original DataFrame on 'designation'

    active_counts_df.write \
        .option("truncate", "true") \
        .mode("overwrite") \
        .jdbc(url=jdbc_url, table="staging_desig_count", properties=connection_properties)

task_4_1_transformation()