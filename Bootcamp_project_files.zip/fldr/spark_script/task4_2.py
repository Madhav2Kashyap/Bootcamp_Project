from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import *
from pyspark.sql.types import LongType, DateType
from datetime import datetime#, timezone
import sys

def task_4_2_transformation():

    spark = SparkSession.builder\
             .appName("task4_2") \
             .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
             .getOrCreate()

    s3_path_1 = sys.argv[1]
    s3_path_2 = sys.argv[2]
    # s3_path_1 = '/home/gagan/Downloads/bootcamp-project/data/employee_leave_calendar_data.csv'
    # s3_path_2 = '/home/gagan/Downloads/bootcamp-project/data/employee_leave_data.csv'
    # jdbc_url = sys.argv[3]
    # connection_properties = sys.argv[4]
    #
    # connection_properties = json.loads(connection_properties)

    jdbc_url = "jdbc:postgresql://35.170.206.20:5432/advance"
    connection_properties = {
        "user": "priyanshu",
        "password": "1234",
        "driver": "org.postgresql.Driver",
        "batchsize": "50000"  # Set the batch size to 50000 records
    }

    # Read data
    calendar_data = spark.read.csv(s3_path_1, header=True, inferSchema=True)
    leave_data = spark.read.csv(s3_path_2, header=True, inferSchema=True)


    # Get current year and current date
    current_year = datetime.now().year
    current_date = datetime.now().date()

    #Filtering the data for current_year
    calendar_data = calendar_data.filter(year("date")==current_year)
    leave_data = leave_data.filter(year("date")==current_year)

    # Convert date columns to DateType
    to_date = lambda col: col.cast(DateType())
    leave_data = leave_data.withColumn("leave_date", to_date(col("date"))).drop("date")
    calendar_data = calendar_data.withColumn("calendar_date", to_date(col("date"))).drop("date")

    # Filter leave data of leaves which are about to come
    leave_data_filtered = leave_data.filter(col("leave_date") > current_date)

    # Filter the DataFrame to include only dates after the current date
    holidays_upcoming = calendar_data.filter(col("calendar_date") > current_date)
    holidays_upcoming = holidays_upcoming.filter(dayofweek(col("calendar_date")).isin([2, 3, 4, 5, 6]))

    # Count the rows in the filtered DataFrame
    holiday_days_count = holidays_upcoming.count()

    # Collect calendar_date values into a list
    calendar_dates = [row.calendar_date for row in holidays_upcoming.select("calendar_date").collect()]

    # Define expression for weekends 1 is Sunday and 7 is Saturday
    weekend_expr = dayofweek(col("leave_date")).isin([1, 7])

    # Filter out weekends and holidays
    leave_data_filtered = leave_data_filtered.filter(~(weekend_expr | col("leave_date").isin(calendar_dates)))
    leave_data_filtered = leave_data_filtered.filter(col("status") != "CANCELLED")

    # Remove duplicates
    leave_data_filtered = leave_data_filtered.dropDuplicates(["emp_id", "leave_date"])

    # Calculate total leaves taken by each employee
    leave_count = leave_data_filtered.groupBy("emp_id").agg(count("*").alias("upcoming_leaves"))

    # Calculate end_date for the current year
    end_date = "{}-12-31".format(current_year)

    # Calculate the number of days between current date and end date
    days_diff = spark.sql(f"SELECT datediff(to_date('{end_date}'), current_date()) + 1 as days_diff").collect()[0]['days_diff']

    # Create date range
    date_range = spark.range(0, days_diff).select(expr("date_add(current_date(), cast(id as int))").alias("date"))

    # Filter out weekends (Saturday and Sunday)
    working_days = date_range.filter(dayofweek("date").isin([2, 3, 4, 5, 6])).count()
    total_working_days = working_days - holiday_days_count

    # Calculate potential leaves for the current year
    potential_leaves_year = leave_count.withColumn("potential_leaves_percentage", (col("upcoming_leaves") / total_working_days) * 100)
    upcoming_leaves = potential_leaves_year.select("emp_id","upcoming_leaves").filter(col("potential_leaves_percentage") > 8)
    #potential_leaves_year.orderBy("emp_id").show(30)
    #upcoming_leaves.orderBy("emp_id").show(30)

    upcoming_leaves.write \
        .option("truncate", "true") \
        .mode("overwrite") \
        .jdbc(url=jdbc_url, table="stg_employee_upcoming_leaves" , properties=connection_properties)
    #upcoming_leaves.orderBy("emp_id").show()


task_4_2_transformation()
'''

from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import *
from pyspark.sql.types import LongType, DateType
from datetime import datetime, timezone
import sys
import json

def task_4_2_transformation():

    spark = (SparkSession.builder\
             .appName("task4_2") \
             .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
             .getOrCreate())

    s3_path_1 = sys.argv[1]
    s3_path_2 = sys.argv[2]
    # jdbc_url = sys.argv[3]
    # connection_properties = sys.argv[4]
    #
    # connection_properties = json.loads(connection_properties)

    jdbc_url = "jdbc:postgresql://35.170.206.20:5432/advance"
    connection_properties = {
        "user": "priyanshu",
        "password": "1234",
        "driver": "org.postgresql.Driver",
        "batchsize": "50000"  # Set the batch size to 50000 records
    }

    # Read data
    calendar_data = spark.read.csv(s3_path_1, header=True, inferSchema=True)
    leave_data = spark.read.csv(s3_path_2, header=True, inferSchema=True)


    # Get current year and current date
    current_year = datetime.now().year
    current_date = datetime.now().date()

    #Filtering the data for current_year
    calendar_data = calendar_data.filter(year("date")==current_year)
    leave_data = leave_data.filter(year("date")==current_year)

    # Convert date columns to DateType
    to_date = lambda col: col.cast(DateType())
    leave_data = leave_data.withColumn("leave_date", to_date(col("date"))).drop("date")
    calendar_data = calendar_data.withColumn("calendar_date", to_date(col("date"))).drop("date")

    # Filter leave data of leaves which are about to come
    leave_data_filtered = leave_data.filter(col("leave_date") > current_date)

    # Filter the DataFrame to include only dates after the current date
    holidays_upcoming = calendar_data.filter(col("calendar_date") > current_date)
    holidays_upcoming = holidays_upcoming.filter(dayofweek(col("calendar_date")).isin([2, 3, 4, 5, 6]))

    # Count the rows in the filtered DataFrame
    holiday_days_count = holidays_upcoming.count()

    # Collect calendar_date values into a list
    calendar_dates = [row.calendar_date for row in holidays_upcoming.select("calendar_date").collect()]

    # Define expression for weekends 1 is Sunday and 7 is Saturday
    weekend_expr = dayofweek(col("leave_date")).isin([1, 7])

    # Filter out weekends and holidays
    leave_data_filtered = leave_data_filtered.filter(~(weekend_expr | col("leave_date").isin(calendar_dates)))
    leave_data_filtered = leave_data_filtered.filter(col("status") != "CANCELLED")

    # Remove duplicates
    leave_data_filtered = leave_data_filtered.dropDuplicates(["emp_id", "leave_date"])

    # Calculate total leaves taken by each employee
    leave_count = leave_data_filtered.groupBy("emp_id").agg(count("*").alias("upcoming_leaves"))

    # Calculate end_date for the current year
    end_date = "{}-12-31".format(current_year)

    # Calculate the number of days between current date and end date
    days_diff = spark.sql(f"SELECT datediff(to_date('{end_date}'), current_date()) + 1 as days_diff").collect()[0]['days_diff']

    # Create date range
    date_range = spark.range(0, days_diff).select(expr("date_add(current_date(), cast(id as int))").alias("date"))

    # Filter out weekends (Saturday and Sunday)
    working_days = date_range.filter(dayofweek("date").isin([2, 3, 4, 5, 6])).count()
    total_working_days = working_days - holiday_days_count

    # Calculate potential leaves for the current year
    potential_leaves_year = leave_count.withColumn("potential_leaves_percentage", (col("upcoming_leaves") / total_working_days) * 100)
    stg_employee_upcoming_leaves = potential_leaves_year.select("emp_id","upcoming_leaves").filter(col("potential_leaves_percentage") > 8)
    #potential_leaves_year.orderBy("emp_id").show(30)
    #upcoming_leaves.orderBy("emp_id").show(30)

    # Reading data from Postgres Employee_timestamp_table
    employee_upcoming_leaves_df = spark.read.jdbc(url=jdbc_url, table='employee_upcoming_leaves_table', properties=connection_properties)

    join_condition = (employee_upcoming_leaves_df["emp_id"] == stg_employee_upcoming_leaves["emp_id"]) & \
                     (employee_upcoming_leaves_df["upcoming_leaves"] != stg_employee_upcoming_leaves[
                         "upcoming_leaves"])

    matched_df = employee_upcoming_leaves_df.join(stg_employee_upcoming_leaves, join_condition, "left_outer")

    matched_rows = matched_df.filter(col("stg_employee_upcoming_leaves.emp_id").isNotNull())
    unmatched_rows = matched_df.filter(col("stg_employee_upcoming_leaves.emp_id").isNull())

    updated_rows = matched_rows.withColumn("upcoming_leaves", col("stg_employee_upcoming_leaves.upcoming_leaves")) \
        .select(employee_upcoming_leaves_df.columns)

    new_rows = stg_employee_upcoming_leaves.join(employee_upcoming_leaves_df, join_condition, "left_anti")

    final_df = updated_rows.union(unmatched_rows.select(employee_upcoming_leaves_df.columns)).union(new_rows)

    final_df.write \
        .option("truncate", "true") \
        .mode("overwrite") \
        .jdbc(url=jdbc_url, table="employee_upcoming_leaves_table" , properties=connection_properties)


task_4_2_transformation()
'''