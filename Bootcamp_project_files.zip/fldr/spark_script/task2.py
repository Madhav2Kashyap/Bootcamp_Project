from pyspark.sql import SparkSession, Window
from pyspark.sql.functions import *
from pyspark.sql.functions import min, from_unixtime, desc, lag, to_timestamp
from pyspark.sql.window import Window
import sys
import json

def transform_timestamp_data():
    spark = SparkSession.builder\
        .appName("task2") \
        .config("spark.jars", "/usr/lib/spark/jars/postgresql-42.6.2.jar") \
        .getOrCreate()


    s3_path = sys.argv[1]
    jdbc_url = sys.argv[sys.argv.index('--jdbc_url') + 1]
    connection_properties = sys.argv[sys.argv.index('--cp') + 1]
    table_name = sys.argv[sys.argv.index('--table_name') + 1]

    # Parse the JSON string back into a Python dictionary
    connection_properties = json.loads(connection_properties)

    df_new = spark.read.csv(s3_path, header=True, inferSchema=True)

    # Convert timestamps to dates

    df_new = (df_new.withColumn("start_date", from_unixtime("start_date").cast("date"))
              .withColumn("end_date", from_unixtime("end_date").cast("date"))
              .withColumn("start_date_tmp", from_unixtime(col("start_date").cast('bigint')))
            .withColumn("end_date_tmp", from_unixtime(col("end_date").cast('decimal'))))


    df_new = df_new.withColumn("status",when(col("end_date").isNull(), "ACTIVE").otherwise("INACTIVE"))

    windowSpec = Window.partitionBy("emp_id", "end_date").orderBy(desc("salary"))
    df_new1 = df_new.select('*', row_number().over(windowSpec).alias('row_number')).where(df_new['end_date'].isNull())
    df_new1 = df_new1.select(df_new.emp_id, df_new.designation, df_new.start_date, df_new.end_date, df_new.salary,
                             df_new.start_date_tmp, df_new.end_date_tmp, df_new.status).where(df_new1.row_number > 1)

    # Cleaning df_new
    df_new = df_new.exceptAll(df_new1)

    df_new = df_new.orderBy("emp_id", "start_date_tmp")

    df_new_2 = df_new.select('*').groupBy(df_new.emp_id).agg(min(df_new.start_date)) \
        .withColumn("demo_status", lit("INACTIVE"))
    df_new_2 = df_new_2.withColumnRenamed("emp_id", "e_id")

    tbl_df = spark.read.jdbc(url=jdbc_url, table=table_name, properties=connection_properties)

    condition = ((tbl_df["emp_id"] == df_new_2["e_id"]) & ((tbl_df.end_date).isNull()))

    target_df = tbl_df.alias("s").join(df_new_2.alias("t"), condition, "left") \
        .withColumn("end_date", coalesce("end_date", "min(start_date)")) \
        .withColumn("status", coalesce("demo_status", "status")) \
        .drop("e_id", "min(start_date)", "demo_status")


    target_df = target_df.drop("start_date_tmp", "end_date_tmp")
    df_new = df_new.drop("start_date_tmp", "end_date_tmp")

    target_df.printSchema()

    target_df = target_df.union(df_new)

    windowSpec = Window.partitionBy("emp_id", "start_date", "end_date").orderBy(desc("salary"))
    target_df = target_df.withColumn("row_number", row_number().over(windowSpec)) \
        .filter(col("row_number") == 1) \
        .drop("row_number")

    target_df = target_df.orderBy("emp_id","start_date", "end_date")


    target_df.write \
        .mode("overwrite") \
        .jdbc(url=jdbc_url, table='staging_employee_ts_table', properties=connection_properties)

transform_timestamp_data()