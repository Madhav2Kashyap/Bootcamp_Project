from datetime import datetime, timezone
import boto3

def get_latest_s3_file_path(bucket_name, prefix,**kwargs):
    # Initialize the S3 client
    s3 = boto3.client('s3')
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

    # Define the time range for the current date
    now = datetime.now(timezone.utc)
    start_time = datetime(now.year, now.month, now.day, 0, 0, tzinfo=timezone.utc)
    end_time = datetime(now.year, now.month, now.day, 7, 0, tzinfo=timezone.utc)

    # Get the most recent file within the specified time range
    latest_file = None
    latest_timestamp = datetime(1970, 1, 1, tzinfo=timezone.utc)  # Initialize with UTC timezone

    for obj in response.get('Contents', []):
        obj_last_modified = obj['LastModified'].replace(tzinfo=timezone.utc)  # Make the timestamp timezone-aware
        if not obj['Key'].endswith('/') and (latest_file is None or obj_last_modified > latest_timestamp):
#            if start_time <= obj_last_modified <= end_time and(latest_file is None or obj_last_modified > latest_timestamp):
            if obj['Key'].endswith('.csv'):
                latest_file = obj['Key']
                latest_timestamp = obj_last_modified

    if latest_file:
        s3_path = f's3://{bucket_name}/{latest_file}'
        # Push the s3_path to XCom
        kwargs['ti'].xcom_push(key='s3_path', value=s3_path)
        # Read the data from S3

    else:
        kwargs['ti'].xcom_push(key='s3_path', value="None")
