from datetime import datetime, timezone
import boto3


def task1_move_file(bucket_name, prefix, destination_prefix,**kwargs):
    # Initialize the S3 client
    s3 = boto3.client('s3')

    # List objects within the source prefix
    response = s3.list_objects_v2(Bucket=bucket_name, Prefix=prefix)

    # Initialize variables to track the oldest file
    oldest_file = None
    oldest_timestamp = datetime.now(timezone.utc)  # Initialize with the current time

    # Iterate through the files and find the oldest one
    for obj in response.get('Contents', []):
        obj_last_modified = obj['LastModified'].replace(tzinfo=timezone.utc)  # Ensure timestamp is timezone-aware

        # Check if the object is a file (not a directory) and is a .csv file
        if not obj['Key'].endswith('/') and obj['Key'].endswith('.csv'):
            if oldest_file is None or obj_last_modified < oldest_timestamp:
                oldest_file = obj['Key']
                oldest_timestamp = obj_last_modified

    if oldest_file:
        # Construct the full S3 path for the oldest file
        s3_path = f's3://{bucket_name}/{oldest_file}'

        destination_key = f"{destination_prefix}/{oldest_file.split('/')[-1]}"

        # Copy the file to the destination folder
        copy_source = {'Bucket': bucket_name, 'Key': oldest_file}
        s3.copy_object(CopySource=copy_source, Bucket=bucket_name, Key=destination_key)

        # Delete the original file from the source folder
        s3.delete_object(Bucket=bucket_name, Key=oldest_file)
